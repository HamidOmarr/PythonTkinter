from distutils.cmd import Command
import tkinter as tk

window = tk.Tk()


def ButtonOn():
    if(button['text']=='Light Switch Off'):
        button['text']='Light Switch On'
        button['background']='yellow'

    else:
        button['text']=('Light Switch Off')


    if(button['text']=='Light Switch On'):
        button['background']='black'
        
button = tk.Button(text='Light Switch Off', background='black', foreground='white',command=ButtonOn)
button.pack(pady = 20, padx = 20)


window.mainloop()